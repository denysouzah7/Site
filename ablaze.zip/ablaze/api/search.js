
require('dotenv').config();
const fetch = require('node-fetch');

module.exports = async (req, res) => {
    const { query } = req.query;
    const apis = [
        {
            url: `https://blackmd.online/api/ytsrc?q=${query}&apikey=${process.env.API_KEY_BLACK}`,
            audioUrl: `https://blackmd.online/api/dl/ytaudio?url=`,
        },
        {
            url: `https://yoshinofenixbots.online/api/ytsrc/videos?q=${query}&apikey=${process.env.API_KEY_SHIPPUDEN}`,
            audioUrl: `https://yoshinofenixbots.online/api/dl/ytaudio?url=`,
        }
    ];

    for (const api of apis) {
        try {
            const response = await fetch(api.url);
            const data = await response.json();
            if (data.resultado && data.resultado.length > 0) {
                res.json({ success: true, song: data.resultado[0], audioUrl: api.audioUrl });
                return;
            }
        } catch (error) {
            console.error(`Error with API: ${error}`);
        }
    }

    res.json({ success: false, message: 'Error retrieving the music' });
};
